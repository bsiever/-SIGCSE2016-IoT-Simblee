rm -f ./SIGCSE.zip
zip -r ../SIGCSE.zip ../SIGCSE -x ./SIGCSE/.git**\*                                                               
mv ../SIGCSE.zip .
