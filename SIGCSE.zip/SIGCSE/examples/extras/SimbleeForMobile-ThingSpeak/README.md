# SimbleeForMobile-ThingSpeak-Tweet
A SimbleeForMobile Sketch that demonstrates the use of ThingSpeak.com for posting tweets and as a cloud service.  
